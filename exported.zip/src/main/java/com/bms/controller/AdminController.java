package com.bms.controller;

import org.springframework.stereotype.Controller;

@Controller
public class AdminController {
}
